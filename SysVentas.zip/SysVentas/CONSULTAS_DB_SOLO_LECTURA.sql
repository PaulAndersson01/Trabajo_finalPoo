-- Consultas para comprobar SysBotica en DBeaver (solo lectura).
-- Detén SysBotica antes de conectarte a H2 en DBeaver.

-- Productos, incluidos sus costos unitarios:
SELECT id_producto, nombre, pu AS precio_venta,
       costo_compra, stock, blister_por_caja, tabletas_por_blister
FROM producto
ORDER BY id_producto;

-- Ventas y costos guardados en el momento de registrar la operación:
SELECT v.id_venta, v.fecha_gener, vd.nombre_producto_venta,
       vd.cantidad, vd.pu AS precio_venta_unitario,
       vd.subtotal, vd.costo_unitario
FROM venta v
JOIN venta_detalle vd ON vd.id_venta = v.id_venta
ORDER BY v.fecha_gener DESC, v.id_venta DESC;

-- NOTA: Para las ventas antiguas, costo_unitario puede estar en NULL.
