package pe.edu.upeu.sysventas.utils;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UtilsXResourcesTest {
    @Test void idiomaEspanyolSeCargaDesdeRecursos() {
        var properties = new UtilsX().detectLanguage("es");
        assertEquals("Principal", properties.getProperty("menu.nombre.principal"));
        assertEquals("Salir", properties.getProperty("menuitem.nombre.salir"));
    }
}
