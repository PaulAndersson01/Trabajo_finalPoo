package pe.edu.upeu.sysventas.utils;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.*;

class PaginacionUtilTest {
    @Test void veinteYTresProductosGeneranTresPaginas() {
        List<Integer> datos = IntStream.rangeClosed(1, 23).boxed().toList();
        assertEquals(3, PaginacionUtil.totalPaginas(datos.size(), 10));
        assertEquals(10, PaginacionUtil.obtenerPagina(datos, 0, 10).size());
        assertEquals(10, PaginacionUtil.obtenerPagina(datos, 1, 10).size());
        assertEquals(List.of(21, 22, 23), PaginacionUtil.obtenerPagina(datos, 2, 10));
    }

    @Test void inventarioVacioMuestraUnaPaginaVacia() {
        assertEquals(1, PaginacionUtil.totalPaginas(0, 10));
        assertTrue(PaginacionUtil.obtenerPagina(List.of(), 0, 10).isEmpty());
    }

    @Test void parametrosIncorrectosSonRechazados() {
        assertThrows(IllegalArgumentException.class, () -> PaginacionUtil.totalPaginas(10, 0));
        assertThrows(IllegalArgumentException.class, () -> PaginacionUtil.obtenerPagina(List.of(1), -1, 10));
    }
}
