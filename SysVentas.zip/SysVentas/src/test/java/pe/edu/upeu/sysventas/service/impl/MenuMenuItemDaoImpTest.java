package pe.edu.upeu.sysventas.service.impl;

import org.junit.jupiter.api.Test;
import pe.edu.upeu.sysventas.dto.MenuMenuItenTO;

import java.util.List;
import java.util.Properties;

import static org.junit.jupiter.api.Assertions.*;

class MenuMenuItemDaoImpTest {
    private static final MenuMenuItemDaoImp DAO = new MenuMenuItemDaoImp();

    private static Properties idioma() {
        Properties p = new Properties();
        p.setProperty("menu.nombre.principal", "Principal");
        p.setProperty("menuitem.nombre.salir", "Salir");
        return p;
    }

    private static boolean tiene(List<MenuMenuItenTO> accesos, String nombre) {
        return accesos.stream().anyMatch(item -> nombre.equals(item.getIdNombreObj()));
    }

    @Test void reporteSoloPuedeVerReporteDiario() {
        List<MenuMenuItenTO> acceso = DAO.listaAccesos("Reporte", idioma());
        assertEquals(2, acceso.size()); // Salir y Reporte
        assertTrue(tiene(acceso, "mireporte"));
        assertFalse(tiene(acceso, "miproducto"));
        assertFalse(tiene(acceso, "miventa"));
    }

    @Test void administradoresMantienenTodosLosModulos() {
        for (String rol : List.of("Root", "Administrador")) {
            List<MenuMenuItenTO> acceso = DAO.listaAccesos(rol, idioma());
            assertTrue(tiene(acceso, "miproducto"));
            assertTrue(tiene(acceso, "miventa"));
            assertTrue(tiene(acceso, "mireporte"));
        }
    }
}
