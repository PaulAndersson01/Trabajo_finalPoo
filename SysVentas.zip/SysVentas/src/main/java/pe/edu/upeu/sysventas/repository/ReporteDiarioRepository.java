package pe.edu.upeu.sysventas.repository;

import pe.edu.upeu.sysventas.config.DatabaseConfig;
import pe.edu.upeu.sysventas.model.LineaReporteDiario;
import pe.edu.upeu.sysventas.model.ReporteDiario;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Consulta de solo lectura. No modifica las ventas ni el stock. */
public class ReporteDiarioRepository {
    public ReporteDiario consultar(LocalDate fecha) {
        BigDecimal ingresos = BigDecimal.ZERO;
        BigDecimal costos = BigDecimal.ZERO;
        int ventas = 0;
        int sinCosto = 0;
        List<LineaReporteDiario> lineas = new ArrayList<>();
        try (Connection conn = DatabaseConfig.getConnection()) {
            // Sumar cabeceras, nunca sumarlas después de JOIN porque duplicaría ventas.
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT precio_total FROM venta WHERE fecha_gener = ?")) {
                ps.setDate(1, Date.valueOf(fecha));
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        ventas++;
                        ingresos = ingresos.add(rs.getBigDecimal("precio_total"));
                    }
                }
            }
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT v.id_venta, vd.cantidad, vd.subtotal, vd.costo_unitario, " +
                    "COALESCE(vd.nombre_producto_venta, p.nombre, 'Producto sin nombre') AS medicamento " +
                    "FROM venta v JOIN venta_detalle vd ON vd.id_venta = v.id_venta " +
                    "LEFT JOIN producto p ON p.id_producto = vd.id_producto " +
                    "WHERE v.fecha_gener = ? ORDER BY v.id_venta DESC, vd.id_venta_detalle")) {
                ps.setDate(1, Date.valueOf(fecha));
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        BigDecimal ingreso = rs.getBigDecimal("subtotal");
                        BigDecimal costoUnitario = rs.getBigDecimal("costo_unitario");
                        int cantidad = (int) Math.round(rs.getDouble("cantidad"));
                        BigDecimal costo = null;
                        BigDecimal margen = null;
                        if (costoUnitario  == null) {
                            sinCosto++;
                        } else {
                            costo = costoUnitario.multiply(BigDecimal.valueOf(cantidad));
                            costos = costos.add(costo);
                            margen = ingreso.subtract(costo);
                        }
                        lineas.add(new LineaReporteDiario(
                                rs.getLong("id_venta"), rs.getString("medicamento"), cantidad,
                                ingreso, costo, margen));
                    }
                }
            }
        } catch (SQLException ex) {
            throw new IllegalStateException("No se pudo consultar el reporte diario: " + ex.getMessage(), ex);
        }
        return new ReporteDiario(fecha, ventas, ingresos, costos, sinCosto == 0, sinCosto,
                List.copyOf(lineas));
    }
}
