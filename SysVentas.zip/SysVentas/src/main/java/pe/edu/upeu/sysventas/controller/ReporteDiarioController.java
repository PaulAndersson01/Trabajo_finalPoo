package pe.edu.upeu.sysventas.controller;

import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import pe.edu.upeu.sysventas.model.LineaReporteDiario;
import pe.edu.upeu.sysventas.model.ReporteDiario;
import pe.edu.upeu.sysventas.service.IReporteDiarioService;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

/** Ganancias solo visibles aquí; no durante la atención de la venta. */
public class ReporteDiarioController {
    private final IReporteDiarioService service;
    public ReporteDiarioController(IReporteDiarioService service) { this.service = service; }

    @FXML private DatePicker fechaPicker;
    @FXML private TableView<LineaReporteDiario> tablaDetalle;
    @FXML private Label lblVentas, lblIngresos, lblCostos, lblGanancia, lblAviso;

    @FXML
    public void initialize() {
        TableColumn<LineaReporteDiario,String> colVenta = new TableColumn<>("N.º venta");
        colVenta.setCellValueFactory(v -> new ReadOnlyStringWrapper("" + v.getValue().idVenta()));
        colVenta.setPrefWidth(90);
        TableColumn<LineaReporteDiario,String> colProducto = new TableColumn<>("Medicamento");
        colProducto.setCellValueFactory(v -> new ReadOnlyStringWrapper(v.getValue().medicamento()));
        colProducto.setPrefWidth(275);
        TableColumn<LineaReporteDiario,String> colCantidad = new TableColumn<>("Cantidad");
        colCantidad.setCellValueFactory(v -> new ReadOnlyStringWrapper("" + v.getValue().cantidad()));
        colCantidad.setPrefWidth(95);
        TableColumn<LineaReporteDiario,String> colIngreso = new TableColumn<>("Venta (S/)");
        colIngreso.setCellValueFactory(v -> new ReadOnlyStringWrapper(moneda(v.getValue().ingreso())));
        colIngreso.setPrefWidth(105);
        TableColumn<LineaReporteDiario,String> colCosto = new TableColumn<>("Costo (S/)");
        colCosto.setCellValueFactory(v -> new ReadOnlyStringWrapper(moneda(v.getValue().costo())));
        colCosto.setPrefWidth(105);
        TableColumn<LineaReporteDiario,String> colGanancia = new TableColumn<>("Ganancia estimada (S/)");
        colGanancia.setCellValueFactory(v -> new ReadOnlyStringWrapper(moneda(v.getValue().ganancia())));
        colGanancia.setPrefWidth(170);
        tablaDetalle.getColumns().setAll(colVenta, colProducto, colCantidad, colIngreso, colCosto, colGanancia);
        tablaDetalle.setPlaceholder(new Label("No se registraron ventas para esta fecha"));
        fechaPicker.setValue(LocalDate.now());
        consultar();
    }

    @FXML
    public void consultar() {
        LocalDate fecha = fechaPicker.getValue();
        if (fecha == null) { lblAviso.setText("Selecciona una fecha."); return; }
        try {
            ReporteDiario r = service.consultar(fecha);
            lblVentas.setText(Integer.toString(r.numeroVentas()));
            lblIngresos.setText("S/ " + moneda(r.ingresoTotal()));
            lblCostos.setText(r.costosCompletos() ? "S/ " + moneda(r.costoConocido()) : "Incompleto");
            lblGanancia.setText(r.gananciaEstimada() == null ? "No disponible" : "S/ " + moneda(r.gananciaEstimada()));
            tablaDetalle.setItems(FXCollections.observableArrayList(r.lineas()));
            lblAviso.setText(r.lineasSinCosto() > 0
                    ? "Hay " + r.lineasSinCosto() + " líneas sin costo histórico. No se calcula la ganancia del día. " +
                      "El costo registrado hoy no puede reconstruir ventas pasadas."
                    : "Ganancia bruta estimada = ingresos de ventas - costo de los productos. " +
                      "No descuenta gastos ni realiza un cálculo tributario.");
        } catch (Exception ex) {
            lblAviso.setText("Error al cargar reporte: " + ex.getMessage());
            tablaDetalle.getItems().clear();
            lblVentas.setText("-"); lblIngresos.setText("-"); lblCostos.setText("-"); lblGanancia.setText("-");
        }
    }

    private static String moneda(BigDecimal valor) {
        return valor == null ? "Sin costo" : valor.setScale(2, RoundingMode.HALF_UP).toPlainString();
    }
}
