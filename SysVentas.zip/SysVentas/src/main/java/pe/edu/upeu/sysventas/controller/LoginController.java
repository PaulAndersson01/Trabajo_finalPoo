package pe.edu.upeu.sysventas.controller;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Screen;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.sysventas.SysVentas;
import pe.edu.upeu.sysventas.components.StageManager;
import pe.edu.upeu.sysventas.config.AppContext;
import pe.edu.upeu.sysventas.config.DatabaseConfig;
import pe.edu.upeu.sysventas.dto.SessionManager;
import pe.edu.upeu.sysventas.model.Usuario;
import pe.edu.upeu.sysventas.service.IUsuarioService;

@RequiredArgsConstructor
public class LoginController {

    final private IUsuarioService us;

    @FXML
    TextField txtUsuario;

    @FXML
    PasswordField txtClave;

    @FXML
    public void login(ActionEvent e) {
        String nombreUsuario = txtUsuario.getText() == null ? "" : txtUsuario.getText().trim();
        String clave = txtClave.getText() == null ? "" : txtClave.getText();

        if (nombreUsuario.isEmpty()) {
            mensaje(e, "Escribe tu nombre de usuario.");
            txtUsuario.requestFocus();
            return;
        }
        if (clave.isBlank()) {
            mensaje(e, "Escribe tu contraseña.");
            txtClave.requestFocus();
            return;
        }

        try {
            us.loginUsuario(nombreUsuario, clave).ifPresentOrElse(
                    usuario -> abrirPantalla(e, usuario),
                    () -> {
                        txtClave.clear();
                        mensaje(e, "Usuario, contraseña o estado de cuenta incorrecto.");
                    });
        } catch (RuntimeException ex) {
            // No mostramos detalles internos de la base de datos en el inicio de sesión.
            mensaje(e, "No se pudo iniciar sesión. Verifica la conexión a la base de datos.");
        }
    }


    public void mensaje(ActionEvent e, String msg){
        Stage stage=(Stage) ((Node)e.getSource()).getScene().getWindow();
        // Un Alert se muestra incluso cuando las coordenadas del popup Toast
        // quedarían fuera de pantalla en una aplicación empaquetada.
        Alert aviso = new Alert(Alert.AlertType.WARNING, msg, ButtonType.OK);
        aviso.initOwner(stage);
        aviso.setTitle("SysBotica - Inicio de sesión");
        aviso.setHeaderText(null);
        aviso.showAndWait();
    }

    private static String mensajeCausa(Throwable ex) {
        Throwable causa = ex;
        while (causa.getCause() != null && causa.getCause() != causa) {
            causa = causa.getCause();
        }
        String detalle = causa.getMessage();
        if (detalle == null || detalle.isBlank()) return causa.getClass().getSimpleName();
        // Mostrar solamente un resumen, no todo el seguimiento de pila.
        return detalle.length() > 350 ? detalle.substring(0, 350) + "..." : detalle;
    }

    @FXML
    public void logout(){
        Platform.exit();
        System.exit(0);
        DatabaseConfig.shutdown();
    }

    public void abrirPantalla(ActionEvent e, Usuario usuario){

        SessionManager.getInstance().setUserId(usuario.getIdUsuario());
        SessionManager.getInstance().setUserName(usuario.getUsuario());
        SessionManager.getInstance().setUserPerfil(usuario.getIdPerfil().getNombre());

        try {
            Screen screen=Screen.getPrimary();
            Rectangle2D rectangle2D=screen.getVisualBounds();
            AppContext appContext=AppContext.getInstance();
            FXMLLoader fxmlLoader = new FXMLLoader(SysVentas.class.getResource("/view/maingui.fxml"));
            fxmlLoader.setControllerFactory(appContext::getBean);
            Scene scene = new Scene(fxmlLoader.load(), rectangle2D.getWidth(), rectangle2D.getHeight());
            scene.getStylesheets().add(SysVentas.class.getResource("/css/style.css").toExternalForm());
            Stage stage=(Stage) ((Node)e.getSource()).getScene().getWindow();

            StageManager.setPrimaryStage(stage);

            stage.setTitle("Hello!");
            stage.setScene(scene);
            stage.setX(rectangle2D.getMinX());
            stage.setY(rectangle2D.getMinY());
            stage.setResizable(true);
            stage.show();

        } catch (Exception | AssertionError ex) {
            // En el EXE no se ve la consola: mostrar un error visible en JavaFX.
            ex.printStackTrace();
            Alert aviso = new Alert(Alert.AlertType.ERROR,
                    "No se pudo abrir el menú principal.\n" +
                    "Detalle: " + mensajeCausa(ex) + "\n" +
                    "Si persiste, ejecuta SysBotica-Diagnostico.exe.",
                    ButtonType.OK);
            aviso.setTitle("SysBotica - Error de apertura");
            aviso.setHeaderText("El usuario fue autenticado, pero el menú no pudo cargarse");
            aviso.showAndWait();
        }

    }






}
