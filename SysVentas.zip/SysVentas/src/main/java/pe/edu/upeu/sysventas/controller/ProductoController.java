package pe.edu.upeu.sysventas.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.sysventas.components.ColumnInfo;
import pe.edu.upeu.sysventas.components.TableViewHelper;
import pe.edu.upeu.sysventas.components.Toast;
import pe.edu.upeu.sysventas.components.ToltipCustom;
import pe.edu.upeu.sysventas.dto.ComboBoxOption;
import pe.edu.upeu.sysventas.enums.TipoProducto;
import pe.edu.upeu.sysventas.model.Producto;
import pe.edu.upeu.sysventas.service.ICategoriaService;
import pe.edu.upeu.sysventas.service.IMarcaService;
import pe.edu.upeu.sysventas.service.IProductoService;
import pe.edu.upeu.sysventas.service.IUnidadMedidaService;
import pe.edu.upeu.sysventas.utils.PaginacionUtil;

import java.util.*;
import java.util.function.Consumer;

@RequiredArgsConstructor
public class ProductoController {
    private final IMarcaService ms;
    private final ICategoriaService cs;
    private final IProductoService ps;
    private final IUnidadMedidaService us;

    @FXML
    TextField txtNombreProducto, txtPUnit, txtCostoCompra,
            txtStock, txtFiltroDato;
    @FXML private VBox panelPastillas, panelStockSimple;
    @FXML private TextField txtCajas, txtBlisterSueltos, txtTabletasSueltas,
            txtBlisterPorCaja, txtTabletasPorBlister;
    @FXML ComboBox<ComboBoxOption> cbxMarca;
    @FXML ComboBox<ComboBoxOption> cbxCategoria;

    @FXML private TableView<Producto> tableView;
    @FXML private Button btnPaginaAnterior, btnPaginaSiguiente;
    @FXML private Label lblPagina;

    private static final int PRODUCTOS_POR_PAGINA = 10;
    private List<Producto> productosFiltrados = List.of();
    private int paginaActual = 0;

    @FXML
    Label lbnMsg;
    @FXML private AnchorPane miContenedor;
    Stage stage;

    private Validator validator;
    ObservableList<Producto> listarProducto;
    Producto formulario;
    Long idProductoCE = 0L;

    private final ToltipCustom ttc=new ToltipCustom();


    @FXML
    public void initialize(){
        System.out.println("Holas");
        cbxMarca.getItems().addAll(ms.listarCombobox());
        cbxCategoria.getItems().addAll(cs.listarCombobox());
        cbxCategoria.valueProperty().addListener((obs, anterior, nuevo) -> mostrarCamposStock());
        txtBlisterPorCaja.setText("8");
        txtTabletasPorBlister.setText("10");
        txtCajas.setText("0"); txtBlisterSueltos.setText("0"); txtTabletasSueltas.setText("0");
        mostrarCamposStock();

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();

        TableViewHelper<Producto> tableViewHelper = new TableViewHelper<>();

        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("ID Pro.", new ColumnInfo("idProducto", 60.0));
        columns.put("Nombre Producto", new ColumnInfo("nombre", 200.0));
        columns.put("P. Unitario", new ColumnInfo("pu", 150.0));
        columns.put("Stock disponible", new ColumnInfo("stock", 330.0));
        columns.put("Marca", new ColumnInfo("idMarca.nombre", 200.0));
        columns.put("Categoria", new ColumnInfo("idCategoria.nombre", 200.0));

        Consumer<Producto> updateAction = producto ->{  editForm(producto); };
        Consumer<Producto> deleteAction = producto -> {

            stage = (Stage) miContenedor.getScene().getWindow();
            Alert confirmar = new Alert(Alert.AlertType.CONFIRMATION,
                    "¿Eliminar " + producto.getNombre() + "? Solo para registros sin ventas.",
                    ButtonType.YES, ButtonType.NO);
            if (confirmar.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;
            try { ps.delete(producto.getIdProducto()); }
            catch (Exception e) {
                new Alert(Alert.AlertType.ERROR,
                    "No se puede eliminar un producto con ventas registradas. " +
                    "Conserva el historial o cambia el stock.").showAndWait();
                return;
            }
            double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
            Toast.showToast(stage, "Se eliminó correctamente!!", 2000, w, h);
            listar();
        };

        tableViewHelper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        // La columna muestra cajas, blisteres y tabletas sin alterar el stock real.
        @SuppressWarnings("unchecked")
        TableColumn<Producto, String> columnaStock = (TableColumn<Producto, String>)(TableColumn<?, ?>)
                tableView.getColumns().stream()
                .filter(c -> "Stock disponible".equals(c.getText())).findFirst().orElseThrow();
        columnaStock.setCellValueFactory(c -> new ReadOnlyStringWrapper(formatearStock(c.getValue())));
        tableView.setTableMenuButtonVisible(true);
        listar();

    }


    @FXML
    public void listar() {
        try {
            txtFiltroDato.clear();
            listarProducto = FXCollections.observableArrayList(ps.findAll());
            aplicarFiltro();
        } catch (RuntimeException e) {
            lbnMsg.setText("No se pudo cargar el inventario. Verifica la base de datos.");
            lbnMsg.setStyle("-fx-text-fill: red;");
        }
    }

    @FXML
    public void buscarProductos() {
        aplicarFiltro();
    }

    private void aplicarFiltro() {
        String filtro = txtFiltroDato.getText().trim().toLowerCase(Locale.ROOT);
        productosFiltrados = listarProducto.stream()
                .filter(p -> p.getNombre() != null && p.getNombre().toLowerCase(Locale.ROOT).contains(filtro))
                .toList();
        paginaActual = 0;
        mostrarPagina();
    }

    private void mostrarPagina() {
        int total = PaginacionUtil.totalPaginas(productosFiltrados.size(), PRODUCTOS_POR_PAGINA);
        paginaActual = Math.min(paginaActual, total - 1);
        tableView.getItems().setAll(PaginacionUtil.obtenerPagina(productosFiltrados, paginaActual, PRODUCTOS_POR_PAGINA));
        lblPagina.setText("Página " + (paginaActual + 1) + " de " + total
                + " · " + productosFiltrados.size() + " medicamentos");
        btnPaginaAnterior.setDisable(paginaActual == 0);
        btnPaginaSiguiente.setDisable(paginaActual >= total - 1);
    }

    @FXML
    private void paginaAnterior() {
        if (paginaActual > 0) {
            paginaActual--;
            mostrarPagina();
        }
    }

    @FXML
    private void paginaSiguiente() {
        if (paginaActual + 1 < PaginacionUtil.totalPaginas(productosFiltrados.size(), PRODUCTOS_POR_PAGINA)) {
            paginaActual++;
            mostrarPagina();
        }
    }

    @FXML
    public void validarFormulario() {
        System.out.println("Holassss Formm");
        if (txtNombreProducto.getText().isBlank()) {
            lbnMsg.setText("Escribe el nombre del medicamento."); return;
        }
        if (cbxCategoria.getValue() == null) {
            lbnMsg.setText("Primero selecciona una categoría."); return;
        }
        if (cbxMarca.getValue() == null) {
            lbnMsg.setText("Selecciona el tipo de marca del medicamento."); return;
        }
        double cantidad;
        try {
            double precio = Double.parseDouble(txtPUnit.getText().trim());
            if (!Double.isFinite(precio) || precio <= 0) {
                lbnMsg.setText("El precio debe ser mayor que cero."); return;
            }
            double costoCompra;
            try { costoCompra = Double.parseDouble(txtCostoCompra.getText().trim()); }
            catch (NumberFormatException ex) {
                lbnMsg.setText("Escribe un costo de compra válido. Ejemplo: 0.30"); return;
            }
            if (!Double.isFinite(costoCompra) || costoCompra <= 0) {
                lbnMsg.setText("Ingresa el costo por unidad (mayor que cero)."); return;
            }
            if (esPastilla()) {
                cantidad = calcularTotalTabletas();
            } else {
                cantidad = enteroNoNegativo(txtStock, "Stock");
            }
        } catch (IllegalArgumentException ex) {
            lbnMsg.setText(ex.getMessage()); return;
        }
        formulario = new Producto();
        formulario.setNombre(txtNombreProducto.getText());
        formulario.setPu(parseDoubleSafe(txtPUnit.getText()));
        formulario.setCostoCompra(parseDoubleSafe(txtCostoCompra.getText()));

        formulario.setPuold(idProductoCE > 0 ? ps.findById(idProductoCE).getPu() : 0.0);
        formulario.setUtilidad(0.0);
        formulario.setStock(cantidad);
        formulario.setBlisterPorCaja(esPastilla() ? enteroPositivo(txtBlisterPorCaja, "Blísteres por caja")
                : (idProductoCE > 0 ? ps.findById(idProductoCE).getBlisterPorCaja() : 8));
        formulario.setTabletasPorBlister(esPastilla() ? enteroPositivo(txtTabletasPorBlister, "Tabletas por blíster")
                : (idProductoCE > 0 ? ps.findById(idProductoCE).getTabletasPorBlister() : 10));
        formulario.setStockold(idProductoCE > 0 ? ps.findById(idProductoCE).getStock() : 0.0);
        formulario.setTipoProducto(TipoProducto.PRODUCTO);

        String idxM = cbxMarca.getSelectionModel().getSelectedItem() == null ? "0"
                : cbxMarca.getSelectionModel().getSelectedItem().getKey();
        formulario.setIdMarca(idxM.equals("0") ? null : ms.findById(Long.parseLong(idxM)));

        String idxC = cbxCategoria.getSelectionModel().getSelectedItem() == null ? "0"
                : cbxCategoria.getSelectionModel().getSelectedItem().getKey();
        formulario.setIdCategoria(idxC.equals("0") ? null : cs.findById(Long.parseLong(idxC)));

        // Unidad interna: cada venta descuenta unidades individuales (tabletas,
        // frascos, tubos, etc. según la categoria del producto).
        formulario.setIdUnidad(us.findById(1L));


        Set<ConstraintViolation<Producto>> violaciones = validator.validate(formulario);
        List<ConstraintViolation<Producto>> violacionesOrdenadas = violaciones.stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();

        if (violacionesOrdenadas.isEmpty()) {
            procesarFormulario();

        } else {
            mostrarErroresValidacion(violacionesOrdenadas);
        }
    }

    private double parseDoubleSafe(String value) {
        if (value == null || value.trim().isEmpty()) return 0.0;
        try { return Double.parseDouble(value.trim()); }
        catch (NumberFormatException e) { return 0.0; }
    }


    public void clearForm() {
        txtNombreProducto.clear();
        txtPUnit.clear(); txtCostoCompra.clear(); txtStock.clear();
        txtCajas.setText("0"); txtBlisterSueltos.setText("0"); txtTabletasSueltas.setText("0");
        txtBlisterPorCaja.setText("8"); txtTabletasPorBlister.setText("10");
        cbxMarca.getSelectionModel().clearSelection();
        cbxCategoria.getSelectionModel().clearSelection();
        idProductoCE = 0L;
        mostrarCamposStock();
        limpiarError();
    }



    public void editForm(Producto producto) {
        txtNombreProducto.setText(producto.getNombre());

        txtPUnit.setText(producto.getPu().toString());
        txtCostoCompra.setText(producto.getCostoCompra() == null ? "" : producto.getCostoCompra().toString());
        txtStock.setText(String.valueOf(producto.getStock().intValue()));
        int bc = Math.max(1, producto.getBlisterPorCaja());
        int tb = Math.max(1, producto.getTabletasPorBlister());
        int total = producto.getStock().intValue();
        txtBlisterPorCaja.setText(String.valueOf(bc));
        txtTabletasPorBlister.setText(String.valueOf(tb));
        txtCajas.setText(String.valueOf(total / (bc * tb)));
        txtBlisterSueltos.setText(String.valueOf((total % (bc * tb)) / tb));
        txtTabletasSueltas.setText(String.valueOf(total % tb));


        cbxMarca.getSelectionModel().select(
                cbxMarca.getItems().stream()
                        .filter(m -> Long.parseLong(m.getKey()) == producto.getIdMarca().getIdMarca())
                        .findFirst().orElse(null));

        cbxCategoria.getSelectionModel().select(
                cbxCategoria.getItems().stream()
                        .filter(c -> Long.parseLong(c.getKey()) == producto.getIdCategoria().getIdCategoria())
                        .findFirst().orElse(null));

        idProductoCE = producto.getIdProducto();
        mostrarCamposStock();
        limpiarError();
    }


    private void mostrarErroresValidacion(List<ConstraintViolation<Producto>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("nombre", txtNombreProducto);
        campos.put("pu", txtPUnit);
        campos.put("costoCompra", txtCostoCompra);
        campos.put("stock", txtStock);
        campos.put("idMarca", cbxMarca);
        campos.put("idCategoria", cbxCategoria);

        LinkedHashMap<String, String> erroresOrdenados = new LinkedHashMap<>();
        final Control[] primerCtrl = {null};
        for (String campo : campos.keySet()) {
            violaciones.stream()
                    .filter(v -> v.getPropertyPath().toString().equals(campo))
                    .findFirst().ifPresent(v -> {

                        erroresOrdenados.put(campo, v.getMessage());

                        Control c = campos.get(campo);
                        if (c != null && !c.getStyleClass().contains("text-field-error")){
                            //c.getStyleClass().add("text-field-error");
                            if (c != null) ttc.marcarError(c, v.getMessage().trim());
                        }
                        if (primerCtrl[0] == null) primerCtrl[0] = c;
                    });
        }
        if (!erroresOrdenados.isEmpty()) {
            lbnMsg.setText(erroresOrdenados.entrySet().iterator().next().getValue());
            lbnMsg.setStyle("-fx-text-fill: red; -fx-font-size: 16px;");
            if (primerCtrl[0] != null) Platform.runLater(primerCtrl[0]::requestFocus);
        }
    }

    private void procesarFormulario() {
        stage = (Stage) miContenedor.getScene().getWindow();
        lbnMsg.setText("Formulario válido");
        lbnMsg.setStyle("-fx-text-fill: green; -fx-font-size: 16px;");
        limpiarError();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            if (idProductoCE > 0L) {
                formulario.setIdProducto(idProductoCE);
                ps.update(idProductoCE, formulario);
                Toast.showToast(stage, "Se actualizó correctamente", 2000, w, h);
            } else {
                ps.save(formulario);
                Toast.showToast(stage, "Se guardó correctamente", 2000, w, h);
            }
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            lbnMsg.setText("No se pudo guardar el medicamento. Revisa los datos y la conexión.");
            lbnMsg.setStyle("-fx-text-fill: red;");
            new Alert(Alert.AlertType.ERROR,
                    "El medicamento no se guardó. Comprueba que la base de datos esté disponible.")
                    .showAndWait();
        }
    }

    public void limpiarError() {
        List.of(txtNombreProducto, txtPUnit, txtCostoCompra, txtStock, cbxMarca, cbxCategoria)
                .forEach(c -> {c.getStyleClass().remove("text-field-error");
                    ttc.limpiarCampo(c);
                });
    }

    private boolean esPastilla() {
        ComboBoxOption opcion = cbxCategoria.getValue();
        if (opcion == null) return false;
        return cs.findById(Long.parseLong(opcion.getKey())).getNombre().equalsIgnoreCase("Pastilla");
    }

    private void mostrarCamposStock() {
        boolean pastilla = esPastilla();
        panelPastillas.setVisible(pastilla);
        panelPastillas.setManaged(pastilla);
        panelStockSimple.setVisible(!pastilla);
        panelStockSimple.setManaged(!pastilla);
    }

    private int enteroNoNegativo(TextField campo, String nombre) {
        try {
            int n = Integer.parseInt(campo.getText().trim());
            if (n < 0) throw new NumberFormatException();
            return n;
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException(nombre + ": escribe un numero entero mayor o igual a cero.");
        }
    }

    private int enteroPositivo(TextField campo, String nombre) {
        int n = enteroNoNegativo(campo, nombre);
        if (n == 0) throw new IllegalArgumentException(nombre + " debe ser mayor que cero.");
        return n;
    }

    private int calcularTotalTabletas() {
        int cajas = enteroNoNegativo(txtCajas, "Cajas");
        int bc = enteroPositivo(txtBlisterPorCaja, "Blísteres por caja");
        int tb = enteroPositivo(txtTabletasPorBlister, "Tabletas por blíster");
        int blister = enteroNoNegativo(txtBlisterSueltos, "Blísteres sueltos");
        int tabletas = enteroNoNegativo(txtTabletasSueltas, "Tabletas sueltas");
        try {
            return Math.addExact(Math.addExact(Math.multiplyExact(Math.multiplyExact(cajas, bc), tb),
                    Math.multiplyExact(blister, tb)), tabletas);
        } catch (ArithmeticException ex) {
            throw new IllegalArgumentException("Cantidad de tabletas demasiado grande.");
        }
    }

    private String formatearStock(Producto p) {
        int total = p.getStock().intValue();
        if (p.getIdCategoria() == null || !"Pastilla".equalsIgnoreCase(p.getIdCategoria().getNombre())) {
            String unidad = switch (p.getIdCategoria() == null ? "" : p.getIdCategoria().getNombre().toLowerCase(Locale.ROOT)) {
                case "jarabe", "gotas" -> " frascos";
                case "crema" -> " tubos";
                default -> " unidades";
            };
            return total + unidad;
        }
        int bc = Math.max(1, p.getBlisterPorCaja());
        int tb = Math.max(1, p.getTabletasPorBlister());
        int cajas = total / (bc * tb);
        int blisteres = (total % (bc * tb)) / tb;
        int sueltas = total % tb;
        return cajas + " cajas + " + blisteres + " blísteres + " + sueltas + " tabletas";
    }

}
