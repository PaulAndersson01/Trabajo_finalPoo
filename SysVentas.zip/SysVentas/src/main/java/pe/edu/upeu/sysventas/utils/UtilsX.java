package pe.edu.upeu.sysventas.utils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.Properties;

public class UtilsX {

    public java.net.URL getFile(String ruta) {
        return this.getClass().getResource("/" + ruta);
    }

    public File getFileExterno(String carpeta, String filex) {
        return Path.of(carpeta, filex).toAbsolutePath().toFile();
    }

    public File getFolderExterno(String carpeta) {
        return Path.of(carpeta).toAbsolutePath().toFile();
    }

    /**
     * Carga la traducción desde el JAR para que funcione también con jpackage.
     * Antes se buscaba solo en ./language, carpeta ausente en el EXE.
     */
    public Properties detectLanguage(String idioma) {
        Properties p = cargarRecursoIdioma("idiomas-" + idioma + ".properties");
        // Defensas para que el menú no falle con NullPointerException.
        p.putIfAbsent("menu.nombre.principal", "Principal");
        p.putIfAbsent("menuitem.nombre.salir", "Salir");
        return p;
    }

    public String readLanguageFile() {
        return cargarRecursoIdioma("SysCenterLife.properties")
                .getProperty("syscenterlife.idioma", "es");
    }

    private Properties cargarRecursoIdioma(String archivo) {
        Properties p = new Properties();
        // Recurso empaquetado: disponible tanto en IntelliJ como en EXE.
        try (InputStream in = getClass().getResourceAsStream("/language/" + archivo)) {
            if (in != null) {
                p.load(in);
                return p;
            }
        } catch (IOException ex) {
            System.err.println("No se pudo cargar el idioma del JAR: " + archivo);
            ex.printStackTrace();
        }
        // Compatibilidad con proyectos antiguos que usan archivos externos.
        File externo = getFileExterno("language", archivo);
        if (externo.isFile()) {
            try (InputStream in = java.nio.file.Files.newInputStream(externo.toPath())) {
                p.load(in);
            } catch (IOException ex) {
                System.err.println("No se pudo cargar el idioma externo: " + archivo);
                ex.printStackTrace();
            }
        }
        return p;
    }
}
