package pe.edu.upeu.sysventas.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/** Resumen del día. Si falta algún costo, no se puede calcular la ganancia total. */
public record ReporteDiario(LocalDate fecha, int numeroVentas, BigDecimal ingresoTotal,
                           BigDecimal costoConocido, boolean costosCompletos,
                           int lineasSinCosto, List<LineaReporteDiario> lineas) {
    public BigDecimal gananciaEstimada() {
        return costosCompletos ? ingresoTotal.subtract(costoConocido) : null;
    }
}
