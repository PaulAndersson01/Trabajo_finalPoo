package pe.edu.upeu.sysventas.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.sysventas.enums.TipoProducto;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Producto {

    private Long idProducto;
    @NotBlank(message = "El nombre del producto es obligatorio")
    private String nombre;
    @NotNull(message = "El tipo de producto es obligatoria")
    private TipoProducto tipoProducto;
    @NotNull(message = "El precio del producto es obligatorio")
    @Positive(message = "El precio del producto debe ser positivo")
    private Double pu;
    @NotNull(message = "El precio anterior del producto es obligatorio")
    @PositiveOrZero(message = "El precio anterior del producto debe ser positivo o cero")
    private Double puold;
    // Costo de adquisición por unidad de venta (tableta, frasco, tubo, etc.).
    // Puede ser NULL en medicamentos antiguos, hasta registrar su costo.
    @Positive(message = "El costo de compra debe ser mayor que cero")
    private Double costoCompra;
    @NotNull(message = "La utilidad es obligatoria")
    @PositiveOrZero(message = "La utilidad no debe ser negativa")
    private Double utilidad;
    @NotNull(message = "El stock del producto es obligatorio")
    @PositiveOrZero(message = "El stock del producto debe ser positivo")
    private Double stock;
    @NotNull(message = "El stock anterior del producto es obligatorio")
    @PositiveOrZero(message = "El stock anterior del producto debe ser positivo")
    private Double stockold;
    // Presentacion de la categoria Pastilla. El stock se guarda en tabletas.
    @Builder.Default private Integer blisterPorCaja = 8;
    @Builder.Default private Integer tabletasPorBlister = 10;

    @NotNull(message = "La categoria del producto es obligatoria")
    private Categoria idCategoria;
    @NotNull(message = "La marca del producto es obligatoria")
    private Marca idMarca;
    @NotNull(message = "La unidad de medida del producto es obligatoria")
    private UnidMedida idUnidad;
}