package pe.edu.upeu.sysventas.controller;


import com.github.anastaciocintra.escpos.EscPos;
import com.github.anastaciocintra.escpos.EscPosConst;
import com.github.anastaciocintra.escpos.Style;
import com.github.anastaciocintra.escpos.barcode.QRCode;
import com.github.anastaciocintra.output.PrinterOutputStream;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import pe.edu.upeu.sysventas.components.*;
import pe.edu.upeu.sysventas.dto.ModeloDataAutocomplet;
import pe.edu.upeu.sysventas.dto.PersonaDto;
import pe.edu.upeu.sysventas.dto.SessionManager;
import pe.edu.upeu.sysventas.dto.comprobante.Comprobante;
import pe.edu.upeu.sysventas.enums.TipoDocumento;
import pe.edu.upeu.sysventas.enums.TipoProducto;
import pe.edu.upeu.sysventas.exception.ModelNotFoundException;
import pe.edu.upeu.sysventas.model.Cliente;
import pe.edu.upeu.sysventas.model.VentCarrito;
import pe.edu.upeu.sysventas.model.Venta;
import pe.edu.upeu.sysventas.model.VentaDetalle;
import pe.edu.upeu.sysventas.service.*;
import pe.edu.upeu.sysventas.utils.ConsultaDNI;
import pe.edu.upeu.sysventas.utils.PrinterManager;

import javax.print.PrintService;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Consumer;


public class VentaController {
    @FXML
    TextField autocompProducto;
    @FXML
    TextField nombreProducto, codigoPro, stockPro, cantidadPro, punitPro, preTPro, txtBaseImp, txtIgv, txtDescuento, txtImporteT;
    @FXML
    Button btnRegVenta, btnRegCarrito, btnFormCliente, btnRegCliente;
    @FXML
    TextField autocompCliente, txtDireccion;
    @FXML
    TextField razonSocial;
    @FXML
    TextField dniRuc;
    @FXML
    TableView<VentCarrito> tableView;
    AutoCompleteTextField actf;
    ModeloDataAutocomplet lastProducto;
    AutoCompleteTextField actfC;
    ModeloDataAutocomplet lastCliente;

    IProductoService ps;
    IClienteService cs;
    IVentaCarritoService daoC;
    IUsuarioService daoU;
    IVentaService daoV;
    IVentaDetalleService daoVD;
    Stage stage;
    @FXML
    private AnchorPane miContenedor;
    private final SortedSet<ModeloDataAutocomplet> entries = new TreeSet<>((ModeloDataAutocomplet o1, ModeloDataAutocomplet o2) -> o1.toString().compareTo(o2.toString()));
    private final SortedSet<ModeloDataAutocomplet> entriesC = new TreeSet<>((ModeloDataAutocomplet o1, ModeloDataAutocomplet o2) -> o1.toString().compareTo(o2.toString()));

    ConsultaDNI cDni;
    TipoProducto tipoProducto;


    public VentaController(IProductoService ps, IClienteService cs, IVentaCarritoService daoC, IUsuarioService daoU, IVentaService daoV, IVentaDetalleService daoVD, ConsultaDNI cDni) {
        this.ps = ps;
        this.cs = cs;
        this.daoC = daoC;
        this.daoU = daoU;
        this.daoV = daoV;
        this.daoVD = daoVD;
        this.cDni = cDni;
    }

    @FXML
    public void initialize(){

        Platform.runLater(() -> {
            stage = (Stage) miContenedor.getScene().getWindow();
            System.out.println("El título del stage es: " + stage.getTitle());
        });

        // Venta simple sin DNI: cliente de mostrador de la base de prueba.
        dniRuc.setText("00000000");
        razonSocial.setText("Publico general");
        listarCliente();
        // No se requiere consultar DNI para ventas de mostrador.

        listarProducto();
        actf = new AutoCompleteTextField<>(entries, autocompProducto);
        // Cuando el usuario ELIGE un medicamento del autocompletado, se llenan sus datos.
        // Antes dependía del evento de teclado, que no siempre ocurre al seleccionar con mouse.
        actf.setOnSelection(seleccion -> seleccionarProducto((ModeloDataAutocomplet) seleccion));

        // Si escribe un nombre distinto al producto seleccionado, no conservar sus datos viejos.
        autocompProducto.textProperty().addListener((obs, anterior, nuevo) -> {
            if (lastProducto != null && !lastProducto.toString().equals(nuevo)) {
                lastProducto = null;
                nombreProducto.clear(); codigoPro.clear(); stockPro.clear();
                punitPro.clear(); preTPro.clear();
                btnRegCarrito.setDisable(true);
            }
        });

        // Calcula con el texto actualizado (onKeyTyped puede ejecutarse antes de insertar el carácter).
        cantidadPro.textProperty().addListener((obs, anterior, nuevo) -> calcularPT());
        personalizarTabla();
        listar(); // Muestra el carrito pendiente si se vuelve a abrir la ventana.
        btnRegCarrito.setDisable(true);
        btnRegCliente.setDisable(true);
    }

    private void seleccionarProducto(ModeloDataAutocomplet seleccion) {
        if (seleccion == null) return;
        lastProducto = seleccion;
        nombreProducto.setText(seleccion.getNameDysplay());
        codigoPro.setText(seleccion.getIdx());
        String[] datos = seleccion.getOtherData().split(":");
        punitPro.setText(datos[0]);
        stockPro.setText(datos[1]);
        tipoProducto = TipoProducto.valueOf(datos[2]);
        cantidadPro.setText("1");
        calcularPT();
    }

    public void listarProducto(){
        entries.addAll(ps.listAutoCompletProducto());
    }
    public void listarCliente(){
        entriesC.clear();
        entriesC.addAll(cs.listAutoCompletCliente());
    }

    public void autoCompletarCliente(){
        actfC=new AutoCompleteTextField<>(entriesC, autocompCliente);
        autocompCliente.setOnKeyReleased(e->{
            lastCliente=(ModeloDataAutocomplet) actfC.getLastSelectedObject();
            if(lastCliente!=null){
                System.out.println(lastCliente.getNameDysplay());
                razonSocial.setText(lastCliente.getNameDysplay());
                dniRuc.setText(lastCliente.getIdx());
                listar();
            }else {
                btnRegCliente.setDisable(true);
                limpiarFormCliente();
            }
        });
    }




    @FXML
    public void buscarClienteCdni(){
        limpiarFormCliente();
        Stage stage = StageManager.getPrimaryStage();
        double with=stage.getMaxWidth()/2;
        if(autocompCliente.getText().length()==8 || autocompCliente.getText().length()==11){
            try {
                if(cs.findById(autocompCliente.getText())!=null){
                    btnRegCliente.setDisable(true);
                    Toast.showToast(stage, "El cliente si existe", 2000, with, 50);
                    return;}
                consultarDNIReniec(with);
            } catch (ModelNotFoundException e) {
                btnRegCliente.setDisable(true);
                Toast.showToast(stage, "El cliente no existe", 2000, with, 50);
                consultarDNIReniec(with);
            }
        }else{
            btnRegCliente.setDisable(true);
            Toast.showToast(stage, "El valor buscado debe tener 8 o 11 digitos", 2000, with, 50);
        }
    }



    public void consultarDNIReniec(double with){
        PersonaDto p=cDni.consultarDNI(autocompCliente.getText());
        if(p!=null){
            razonSocial.setText(p.getNombre()+" "+p.getApellidoPaterno()+" "+p.getApellidoMaterno());
            dniRuc.setText(p.getDni());
            btnRegCliente.setDisable(false);
            Toast.showToast(stage, "El cliente se encontró en RENIEC para registrar debe hacer clik en Add", 2000, with, 50);
        }else{
            btnRegCliente.setDisable(true);
            Toast.showToast(stage, "El cliente no se encuentra en RENIEC y debe registrar a través del formulario de cliente", 2000, with, 50);
        }
    }

    public void limpiarFormCliente(){
        razonSocial.clear();
        dniRuc.clear();
        txtDireccion.clear();
    }


    @FXML
    public void guardarCliente(){
        Stage stage = StageManager.getPrimaryStage();
        double with=stage.getMaxWidth()/2;
        try {
            Cliente c= Cliente.builder().dniruc(dniRuc.getText())
                    .nombres(razonSocial.getText())
                    .repLegal(razonSocial.getText())
                    .tipoDocumento(TipoDocumento.DNI)
                    .direccion(txtDireccion.getText())
                    .build();
            cs.save(c);
            btnRegCliente.setDisable(true);
            Toast.showToast(stage, "El cliente se guardo satisfactoriamente!", 2000, with, 50);
            listarCliente();
            listar();
        }catch (Exception e){
            Toast.showToast(stage, "Error al guardar cliente!", 2000, with, 50);
        }
    }

    public void personalizarTabla(){
        TableViewHelper<VentCarrito> tableViewHelper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("ID Prod", new ColumnInfo("idProducto.idProducto", 100.0)); // Columna visible "Columna 1" mapea al campo "campo1"
        columns.put("Nombre Producto", new ColumnInfo("nombreProducto", 300.0)); // Columna visible "Columna 1" mapea al campo "campo1"
        columns.put("Cantidad", new ColumnInfo("cantidad", 60.0)); // Columna visible "Columna 2" mapea al campo "campo2"
        columns.put("P.Unitario", new ColumnInfo("punitario", 100.0)); // Columna visible "Columna 2" mapea al campo "campo2"
        columns.put("P.Total", new ColumnInfo("ptotal", 100.0)); // Columna visible "Columna 2" mapea al campo "campo2"

        Consumer<VentCarrito> updateAction = (VentCarrito ventCarrito) -> { System.out.println("Actualizar: " + ventCarrito); };
        Consumer<VentCarrito> deleteAction = (VentCarrito ventCarrito) -> {deleteReg(ventCarrito); };

        tableViewHelper.addColumnsInOrderWithSize(tableView, columns,updateAction, deleteAction );

        tableView.setTableMenuButtonVisible(true);
    }

    public void listar(){
        tableView.getItems().clear();
        List<VentCarrito> lista=daoC.listaCarritoCliente(dniRuc.getText());
        double impoTotal = 0, igv = 0;
        for (VentCarrito dato: lista){
            impoTotal += Double.parseDouble(String.valueOf(dato.getPtotal()));
        }
        txtImporteT.setText(String.format(Locale.US, "%.2f", impoTotal));
        double pv = Math.round((impoTotal / 1.18) * 100.0) / 100.0;
        txtBaseImp.setText(String.format(Locale.US, "%.2f", pv));
        txtIgv.setText(String.format(Locale.US, "%.2f", impoTotal - pv));
        txtDescuento.setText("0.00");
        tableView.getItems().addAll(lista);
    }

    public void editVenCarrito(VentCarrito obj) {
        System.out.println(obj.getDniruc());
    }

    public void deleteReg(VentCarrito obj) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmación");
        alert.setHeaderText("Confirmar acción");
        alert.setContentText("¿Estás seguro de que deseas eliminar este elemento?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            daoC.delete(obj.getIdCarrito());
            Stage stage = StageManager.getPrimaryStage();
            double with=stage.getMaxWidth()/2;
            Toast.showToast(stage, "¡Acción completada!", 2000, with, 50);
            listar();
        } else {
            System.out.println("Acción cancelada");
        }
    }

    /**
     * Restablece solo los datos del medicamento seleccionado.
     * No modifica la lista de productos añadidos al carrito ni su total.
     */
    @FXML
    private void limpiarCamposProducto() {
        autocompProducto.clear();
        nombreProducto.clear();
        codigoPro.clear();
        stockPro.clear();
        cantidadPro.clear();
        punitPro.clear();
        preTPro.clear();
        lastProducto = null;
        tipoProducto = null;
        if (actf != null) {
            actf.clearSelection();
        }
        btnRegCarrito.setDisable(true);
        autocompProducto.requestFocus();
    }

    @FXML
    private void calcularPT(){
        btnRegCarrito.setDisable(true);
        preTPro.clear();
        if (codigoPro.getText().isBlank() || cantidadPro.getText().isBlank()
                || punitPro.getText().isBlank() || stockPro.getText().isBlank()) return;
        try {
            double cantidad = Double.parseDouble(cantidadPro.getText().trim());
            double precio = Double.parseDouble(punitPro.getText().trim());
            double stock = Double.parseDouble(stockPro.getText().trim());
            if (!Double.isFinite(cantidad) || !Double.isFinite(precio)
                    || cantidad <= 0 || cantidad != Math.floor(cantidad) || precio <= 0) return;
            preTPro.setText(String.format(Locale.US, "%.2f", cantidad * precio));
            btnRegCarrito.setDisable(cantidad > stock);
        } catch (NumberFormatException ignored) {
            // Hasta escribir una cantidad valida, Agregar permanece desactivado.
        }
    }

    @FXML
    private void registarPCarrito(){
        System.out.println("ID:"+SessionManager.getInstance().getUserId());
        try {
            double cantidad = Double.parseDouble(cantidadPro.getText());
            double disponible = Double.parseDouble(stockPro.getText());
            if (cantidad <= 0 || cantidad != Math.floor(cantidad) || cantidad > disponible) {
                new Alert(Alert.AlertType.WARNING,
                    "La cantidad debe ser entera y no superar el stock disponible.").showAndWait();
                return;
            }
            VentCarrito ss= VentCarrito.builder()
                    .dniruc(dniRuc.getText())
                    .idProducto(ps.findById(Long.parseLong(codigoPro.getText())))
                    .nombreProducto(nombreProducto.getText())
                    .cantidad(Double.parseDouble(cantidadPro.getText()))
                    .punitario(Double.parseDouble(punitPro.getText()))
                    .ptotal(Double.parseDouble(preTPro.getText()))
                    .estado(1)
                    .idUsuario(daoU.findById(SessionManager.getInstance().getUserId()))
                    .tipoProducto(tipoProducto)
                    .build();
            daoC.save(ss);
            listar();

            limpiarCamposProducto();
        }catch (Exception e){
            new Alert(Alert.AlertType.ERROR,
                    "No se pudo agregar el medicamento: " + e.getMessage(), ButtonType.OK).showAndWait();
        }
    }

    @FXML
    public void registrarVenta(){
        Locale locale = new Locale("es", "es-PE");
        LocalDateTime localDate = LocalDateTime.now();
        //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss", locale);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy", locale);
        String fechaFormateada = localDate.format(formatter);
        List<VentCarrito> dd = daoC.listaCarritoCliente(dniRuc.getText());
        if(dd.size()>0){
            Venta to=Venta.builder()
                    .dniruc(cs.findById(dniRuc.getText()))
                    .precioBase(Double.parseDouble(txtBaseImp.getText()))
                    .igv(Double.parseDouble(txtIgv.getText()))
                    .precioTotal(Double.parseDouble(txtImporteT.getText()))
                    .idUsuario(daoU.findById(SessionManager.getInstance().getUserId()))
                    .serie("V")
                    .tipoDoc("Registro interno")
                    .fechaGener(LocalDate.parse(fechaFormateada, formatter))
                    .numDoc("00" )
                    .build();
            Venta idX;
            try {
                // Guarda venta, detalles y resta existencias como una unidad.
                idX = daoV.registrarConInventario(to, dd);
            } catch (Exception ex) {
                new Alert(Alert.AlertType.ERROR,
                        "No se registró la venta: " + ex.getMessage(),
                        ButtonType.OK).showAndWait();
                return;
            }
            listar();
            limpiarCamposProducto();
            entries.clear();
            listarProducto(); // Actualizar el stock ofrecido por el autocompletado.
            // La venta ya se guardó. No emitimos una boleta fiscal falsa
            // ni intentamos imprimir en una impresora no configurada.
            new Alert(Alert.AlertType.INFORMATION,
                    "Venta registrada correctamente. Inventario actualizado.",
                    ButtonType.OK).showAndWait();

        }else{
            Stage stage = StageManager.getPrimaryStage();
            double with=stage.getMaxWidth()/2;
            Toast.showToast(stage, "No hay productos en el carrito", 2000, with, 50);
        }
    }

    public void mostrarVisorComprobante(Comprobante boleta) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/main_comprobante.fxml"));
            Parent visorRoot = loader.load();
            MainComprobanteController controller = loader.getController();
            controller.pasarDatos(boleta);
            Alert alert = new Alert(Alert.AlertType.NONE);
            alert.setTitle("Visualizar Comprobante");
            alert.setHeaderText(null);
            if (visorRoot instanceof javafx.scene.layout.Region) {
                ((javafx.scene.layout.Region) visorRoot).setPrefSize(800, 600);
            }
            StackPane stackPane = new StackPane(visorRoot);
            alert.getDialogPane().setContent(stackPane);
            ButtonType closeButton = new ButtonType("Cerrar");
            alert.getButtonTypes().add(closeButton);
            alert.setOnCloseRequest(event -> alert.close());
            alert.showAndWait().ifPresent(response -> {
                if (response == closeButton) {
                    alert.close();
                }
            });
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void print(Long idv){
        Venta vt=daoV.findById(idv);
        try {
            PrinterManager printerManager = PrinterManager.getInstance();
            PrintService printService = printerManager.getPrintService();
            PrinterOutputStream printerOutputStream = new PrinterOutputStream(printService);
            EscPos escpos = new EscPos(printerOutputStream);
            Style titleStyle = new Style()
                    .setJustification(EscPosConst.Justification.Center)
                    .setBold(true)
                    .setFontSize(Style.FontSize._2, Style.FontSize._2);
            Style normal = new Style()
                    .setJustification(EscPosConst.Justification.Left_Default);
            Style center = new Style()
                    .setJustification(EscPosConst.Justification.Center);
            escpos.writeLF(titleStyle, "BOLETA DE VENTA");
            escpos.writeLF(center, "Tienda Demo S.A.C.");
            escpos.writeLF(center, "RUC: 12345678901");
            escpos.writeLF(center, "Av. Principal 123 - Lima");
            escpos.writeLF(center, "--------------------------------");
//Datos del cliente
            escpos.writeLF(normal, "Cliente: "+vt.getDniruc().getNombres());
            escpos.writeLF(normal, "DNI: "+vt.getDniruc().getDniruc());
            escpos.writeLF(normal, "Fecha: "+vt.getFechaGener()+"");
            escpos.writeLF(normal, "--------------------------------");
//Detalle
            escpos.writeLF(normal, "Cant Descripción Importe");
            int x=1;
            for(VentaDetalle vd:vt.getDetalleVenta()) {
                String punit=x+" "+vd.getIdProducto().getNombre()+" S/ "+vd.getSubtotal()+"";
                escpos.writeLF(normal, punit);
            }
            escpos.writeLF(normal, "--------------------------------");
            escpos.writeLF(normal, "TOTAL: S/"+vt.getPrecioTotal()+"");
            escpos.writeLF(normal, "--------------------------------");
//Agregar QR con los datos principales
            String qrData = "Boleta N°001-000123 | Total: S/ "+vt.getPrecioTotal()+" | Fecha: "+vt.getFechaGener();
            QRCode qrCode = new QRCode()
                    .setJustification(EscPosConst.Justification.Center)
                    .setErrorCorrectionLevel(QRCode.QRErrorCorrectionLevel.QR_ECLEVEL_M_Default)
                    .setModel(QRCode.QRModel._1_Default);
            escpos.write(qrCode, qrData);
            escpos.feed(2);
            escpos.writeLF(center, "Gracias por su compra!");
            escpos.feed(6);
//Corte total
            escpos.cut(EscPos.CutMode.FULL);
            escpos.close();
            System.out.println("Boleta impresa correctamente.");
            System.out.println("Impresión completada correctamente.");
        } catch (IOException e) {
            System.err.println("Error al inicializar la impresora: " + e.getMessage());
        }
    }


}