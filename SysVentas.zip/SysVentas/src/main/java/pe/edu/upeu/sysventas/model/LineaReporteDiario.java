package pe.edu.upeu.sysventas.model;

import java.math.BigDecimal;

/** Una línea de venta real guardada en la base de datos. */
public record LineaReporteDiario(long idVenta, String medicamento, int cantidad,
                                BigDecimal ingreso, BigDecimal costo, BigDecimal ganancia) {
}
