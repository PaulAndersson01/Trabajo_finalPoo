package pe.edu.upeu.sysventas.service.impl;

import java.time.LocalDate;
import pe.edu.upeu.sysventas.model.ReporteDiario;
import pe.edu.upeu.sysventas.repository.ReporteDiarioRepository;
import pe.edu.upeu.sysventas.service.IReporteDiarioService;

public class ReporteDiarioServiceImp implements IReporteDiarioService {
    private final ReporteDiarioRepository repo;
    public ReporteDiarioServiceImp(ReporteDiarioRepository repo) { this.repo = repo; }
    @Override public ReporteDiario consultar(LocalDate fecha) { return repo.consultar(fecha); }
}
