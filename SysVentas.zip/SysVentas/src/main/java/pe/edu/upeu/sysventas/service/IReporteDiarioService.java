package pe.edu.upeu.sysventas.service;

import java.time.LocalDate;
import pe.edu.upeu.sysventas.model.ReporteDiario;

public interface IReporteDiarioService {
    ReporteDiario consultar(LocalDate fecha);
}
