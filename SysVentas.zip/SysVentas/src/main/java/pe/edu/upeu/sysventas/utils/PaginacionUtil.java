package pe.edu.upeu.sysventas.utils;

import java.util.List;

/** Paginación local de un listado (la base de datos original no se modifica). */
public final class PaginacionUtil {
    private PaginacionUtil() { }

    public static int totalPaginas(int cantidadElementos, int tamPagina) {
        if (cantidadElementos < 0 || tamPagina <= 0) {
            throw new IllegalArgumentException("Cantidad y tamaño de página inválidos.");
        }
        return Math.max(1, (cantidadElementos / tamPagina) + (cantidadElementos % tamPagina == 0 ? 0 : 1));
    }

    public static <T> List<T> obtenerPagina(List<T> datos, int pagina, int tamPagina) {
        if (datos == null || tamPagina <= 0 || pagina < 0) {
            throw new IllegalArgumentException("Parámetros de paginación inválidos.");
        }
        int inicio = (int) Math.min((long) pagina * tamPagina, datos.size());
        int fin = Math.min(inicio + tamPagina, datos.size());
        return datos.subList(inicio, fin);
    }
}
