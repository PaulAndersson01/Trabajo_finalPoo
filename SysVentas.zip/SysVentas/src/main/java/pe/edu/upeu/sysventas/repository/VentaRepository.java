package pe.edu.upeu.sysventas.repository;

import pe.edu.upeu.sysventas.model.*;

import java.sql.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Optional;

public class VentaRepository extends AbstractJpaRepository<Venta, Long> {
    @Override protected String getTableName() { return "venta"; }
    @Override protected String getPkColumn()  { return "id_venta"; }

    @Override
    protected Venta mapRow(ResultSet rs) throws SQLException {
        // Construye cliente con nombre si la columna existe (viene del JOIN en findById)
        Cliente.ClienteBuilder cliBuilder = Cliente.builder().dniruc(rs.getString("dniruc"));
        try { cliBuilder.nombres(rs.getString("nombres")); } catch (SQLException ignored) {}

        Usuario usuario = new Usuario();
        usuario.setIdUsuario(rs.getLong("id_usuario"));
        return Venta.builder()
                .id(rs.getLong("id_venta"))
                .precioBase(rs.getDouble("precio_base"))
                .igv(rs.getDouble("igv"))
                .precioTotal(rs.getDouble("precio_total"))
                .dniruc(cliBuilder.build())
                .idUsuario(usuario)
                .numDoc(rs.getString("num_doc"))
                .fechaGener(rs.getTimestamp("fecha_gener")
                        .toInstant()
                        .atZone(ZoneId.systemDefault()) // O ZoneId.of("America/Lima"), etc.
                        .toLocalDate())
                .serie(rs.getString("serie")).tipoDoc(rs.getString("tipo_doc"))
                .build();
    }

    @Override
    protected Venta insert(Connection conn, Venta e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO venta(precio_base,igv,precio_total,dniruc,id_usuario,num_doc,fecha_gener,serie,tipo_doc) VALUES(?,?,?,?,?,?,?,?,?)",
                e.getPrecioBase(), e.getIgv(), e.getPrecioTotal(),
                e.getDniruc().getDniruc(), e.getIdUsuario().getIdUsuario(),
                e.getNumDoc(), e.getFechaGener(),
                e.getSerie(), e.getTipoDoc());
        e.setId(id);
        return e;
    }

    @Override
    protected Venta updateRow(Connection conn, Venta e) throws SQLException {
        executeUpdate(conn,
                "UPDATE venta SET precio_base=?,igv=?,precio_total=?,dniruc=?,id_usuario=?,num_doc=?,fecha_gener=?,serie=?,tipo_doc=? WHERE id_venta=?",
                e.getPrecioBase(), e.getIgv(), e.getPrecioTotal(),
                e.getDniruc().getDniruc(), e.getIdUsuario().getIdUsuario(),
                e.getNumDoc(), e.getFechaGener(),
                e.getSerie(), e.getTipoDoc(), e.getId());
        return e;
    }

    /**
     * SysBotica: registra cabecera, detalles y salida de inventario
     * en UNA transaccion. Si falla cualquier paso se revierte todo.
     */
    public Venta registrarConInventario(Venta venta, List<VentCarrito> carrito) {
        if (carrito == null || carrito.isEmpty()) {
            throw new IllegalArgumentException("No hay productos en el carrito.");
        }
        try (Connection conn = openConnection()) {
            conn.setAutoCommit(false);
            try {
                // Costo de compra actual: se guarda como foto histórica del momento de la venta.
                // Los productos antiguos pueden tener costo NULL (ganancia aún desconocida).
                Map<Long, java.math.BigDecimal> costos = new HashMap<>();
                try (PreparedStatement psCosto = conn.prepareStatement(
                        "SELECT costo_compra FROM producto WHERE id_producto = ?")) {
                    for (VentCarrito item : carrito) {
                        long idProducto = item.getIdProducto().getIdProducto();
                        psCosto.setLong(1, idProducto);
                        try (ResultSet rs = psCosto.executeQuery()) {
                            if (!rs.next()) throw new IllegalArgumentException("Medicamento no encontrado: " + idProducto);
                            costos.put(idProducto, rs.getBigDecimal("costo_compra"));
                        }
                    }
                }
                // Se comprueba y descuenta el stock antes de guardar la venta.
                // La condicion stock >= ? impide vender unidades inexistentes.
                for (VentCarrito item : carrito) {
                    if (item.getCantidad() == null || !Double.isFinite(item.getCantidad())
                            || item.getCantidad() <= 0) {
                        throw new IllegalArgumentException("La cantidad debe ser mayor que cero.");
                    }
                    try (PreparedStatement ps = conn.prepareStatement(
                            "UPDATE producto SET stock = stock - ? " +
                            "WHERE id_producto = ? AND stock >= ?")) {
                        ps.setDouble(1, item.getCantidad());
                        ps.setLong(2, item.getIdProducto().getIdProducto());
                        ps.setDouble(3, item.getCantidad());
                        if (ps.executeUpdate() != 1) {
                            throw new IllegalStateException("Stock insuficiente del producto: "
                                    + item.getNombreProducto());
                        }
                    }
                }

                Venta registrada = insert(conn, venta);
                List<VentaDetalle> detalles = new ArrayList<>();
                try (PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO venta_detalle (pu,cantidad,descuento,subtotal,id_venta,id_producto,costo_unitario,nombre_producto_venta) " +
                        "VALUES (?,?,?,?,?,?,?,?)")) {
                    for (VentCarrito item : carrito) {
                        ps.setDouble(1, item.getPunitario());
                        ps.setDouble(2, item.getCantidad());
                        ps.setDouble(3, 0.0);
                        ps.setDouble(4, item.getPtotal());
                        ps.setLong(5, registrada.getId());
                        long idProducto = item.getIdProducto().getIdProducto();
                        ps.setLong(6, idProducto);
                        java.math.BigDecimal costo = costos.get(idProducto);
                        if (costo == null) ps.setNull(7, Types.DECIMAL);
                        else ps.setBigDecimal(7, costo);
                        ps.setString(8, item.getNombreProducto());
                        ps.executeUpdate();
                        detalles.add(VentaDetalle.builder()
                                .idVenta(registrada)
                                .idProducto(Producto.builder()
                                        .idProducto(item.getIdProducto().getIdProducto())
                                        .nombre(item.getNombreProducto()).build())
                                .cantidad(item.getCantidad())
                                .pu(item.getPunitario())
                                .descuento(0.0)
                                .subtotal(item.getPtotal())
                                .build());
                    }
                }
                try (PreparedStatement ps = conn.prepareStatement(
                        "DELETE FROM vent_carrito WHERE dniruc = ?")) {
                    ps.setString(1, venta.getDniruc().getDniruc());
                    ps.executeUpdate();
                }
                conn.commit();
                registrada.setDetalleVenta(detalles);
                return registrada;
            } catch (Exception ex) {
                conn.rollback();
                throw ex;
            }
        } catch (SQLException e) {
            throw new RuntimeException("No se pudo registrar la venta: " + e.getMessage(), e);
        }
    }

    /**
     * findById con JOIN a cliente + eager-load de detalles.
     * Necesario para JasperReports y impresión ESC/POS.
     */
    @Override
    public Optional<Venta> findById(Long id) {
        Optional<Venta> opt = executeQueryOne(
                "SELECT v.*, c.nombres FROM venta v " +
                "JOIN cliente c ON v.dniruc = c.dniruc WHERE v.id_venta = ?", id);
        opt.ifPresent(v -> v.setDetalleVenta(loadDetalles(id)));
        return opt;
    }

    private List<VentaDetalle> loadDetalles(Long idVenta) {
        List<VentaDetalle> detalles = new ArrayList<>();
        String sql = "SELECT vd.*, p.nombre AS prod_nombre FROM venta_detalle vd " +
                     "JOIN producto p ON vd.id_producto = p.id_producto WHERE vd.id_venta = ?";
        try (Connection conn = openConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idVenta);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    detalles.add(VentaDetalle.builder()
                            .idVentaDetalle(rs.getLong("id_venta_detalle"))
                            .pu(rs.getDouble("pu")).cantidad(rs.getDouble("cantidad"))
                            .descuento(rs.getDouble("descuento")).subtotal(rs.getDouble("subtotal"))
                            .idProducto(Producto.builder().idProducto(rs.getLong("id_producto"))
                                    .nombre(rs.getString("prod_nombre")).build())
                            .build());
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error cargando detalles de venta", e);
        }
        return detalles;
    }
}
