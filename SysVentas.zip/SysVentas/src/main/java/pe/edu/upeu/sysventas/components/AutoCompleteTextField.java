package pe.edu.upeu.sysventas.components;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Side;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;

import java.util.SortedSet;
import java.util.function.Consumer;

public class AutoCompleteTextField<T>{

    private TextField autoCompleteTextField;
    private final SortedSet<T> entries;
    private final ContextMenu entryMenu = new ContextMenu();
    VBox vbox = new VBox();
    private T lastSelectedObject;
    private Consumer<T> onSelection;

    public AutoCompleteTextField(SortedSet<T> entries, TextField autTF) {
        this.entries = entries;
        this.autoCompleteTextField=autTF;
        //this.autoCompleteTextField.setOnKeyReleased(this::handleKeyReleased);
        this.autoCompleteTextField.setOnKeyTyped(this::handleKeyReleased);
    }

    public void handleKeyReleased(KeyEvent event) {
        acccion();
    }

    // Método para manejar clics del mouse


    public void acccion(){
        ObservableList<MenuItem> menuItems = FXCollections.observableArrayList();
        String input = this.autoCompleteTextField.getText().toLowerCase();

        // Filtro de elementos que coinciden con la entrada
        entries.stream()
                .filter(e -> e.toString().toLowerCase().contains(input))
                .forEach(entry -> {
                    MenuItem item = new MenuItem(entry.toString());
                    //vbox.getChildren().add(new Button(item.getText()));
                    item.setOnAction(e -> {
                        this.autoCompleteTextField.setText(entry.toString());
                        lastSelectedObject = entry;
                        entryMenu.hide();
                        if (onSelection != null) onSelection.accept(entry);
                    });

                    menuItems.add(item);
                    entryMenu.hide();
                });
        /*ScrollPane scrollPane = new ScrollPane(vbox);
        scrollPane.setPrefHeight(150); // Altura del área de scroll
        scrollPane.setFitToWidth(true);
        CustomMenuItem scrollableItem = new CustomMenuItem(scrollPane, false);
        entryMenu.getItems().setAll(scrollableItem);*/
        entryMenu.getItems().setAll(menuItems);
        if (!menuItems.isEmpty()) {
            entryMenu.show(this.autoCompleteTextField, Side.BOTTOM, 0, 0);
        } else {
            entryMenu.hide();
        }
    }

    /** Olvida la selección anterior al limpiar el formulario de ventas. */
    public void clearSelection() {
        lastSelectedObject = null;
        entryMenu.hide();
    }

    /** Notifica al formulario cuando se elige una opción del buscador. */
    public void setOnSelection(Consumer<T> onSelection) {
        this.onSelection = onSelection;
    }

    public ContextMenu getEntryMenu() {
        return entryMenu;
    }

    public T getLastSelectedObject() {
        return lastSelectedObject;
    }
}
