package pe.edu.upeu.sysventas.service.impl;

import pe.edu.upeu.sysventas.dto.MenuMenuItenTO;
import pe.edu.upeu.sysventas.service.IMenuMenuItemDao;

import java.util.*;

public class MenuMenuItemDaoImp implements IMenuMenuItemDao {
    @Override
    public List<MenuMenuItenTO> listaAccesos(String perfil, Properties idioma) {
        List<MenuMenuItenTO> lista = new ArrayList<>();

        lista.add(new MenuMenuItenTO("miprincipal", "/view/login.fxml",
                idioma.getProperty("menu.nombre.principal", "Principal"),
                idioma.getProperty("menuitem.nombre.salir", "Salir"), "Salir", "C"));

        lista.add(new MenuMenuItenTO("miproducto", "/view/main_producto.fxml",
                "Botica", "Productos e inventario", "Gestionar medicamentos", "T"));
        lista.add(new MenuMenuItenTO("miventa", "/view/main_venta.fxml",
                "Botica", "Registrar venta", "Ventas de la botica", "T"));
        lista.add(new MenuMenuItenTO("mireporte", "/view/main_reporte_diario.fxml",
                "Botica", "Reporte diario", "Reporte diario", "T"));

        List<MenuMenuItenTO> accesoReal = new ArrayList<>();
        accesoReal.add(lista.get(0));
        // Root y Administrador gestionan inventario, ventas y reportes;
        // el perfil Reporte solo debe consultar el informe diario.
        switch (perfil) {
            case "Administrador":
            case "Root":
                accesoReal.add(lista.get(1));
                accesoReal.add(lista.get(2));
                accesoReal.add(lista.get(3));
                break;
            case "Reporte":
                accesoReal.add(lista.get(3));
                break;
            default:
                throw new IllegalArgumentException("Perfil desconocido: " + perfil);
        }
        return accesoReal;

    }

    @Override
    public Map<String, String[]> accesosAutorizados(List<MenuMenuItenTO> accesos) {
        Map<String, String[]> menuConfig = new HashMap<>();
        for (MenuMenuItenTO menu : accesos) {
            menuConfig.put("mi" + menu.getIdNombreObj(),  new String[]{menu.getRutaFile(), menu.getNombreTab(),menu.getTipoTab() });
        }
        return menuConfig;
    }

    @Override
    public int[] contarMenuMunuItem(List<MenuMenuItenTO> data) {
        int menui = 0, menuitem = 0;
        String menuN = "";
        for (MenuMenuItenTO mmiItem : data) {
            if (!mmiItem.getMenunombre().equals(menuN)) {
                menuN = mmiItem.getMenunombre();
                menui++;
            }
            if (!mmiItem.getMenuitemnombre().equals("")) {
                menuitem++;
            }
        }
        return new int[]{menui, menuitem};
    }
}
