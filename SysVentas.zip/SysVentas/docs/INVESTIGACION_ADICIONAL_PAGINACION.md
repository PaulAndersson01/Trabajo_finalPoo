# Investigación adicional implementada: paginación del inventario

## Problema identificado
Cuando la botica registra numerosos medicamentos, mostrar todos los productos en una única tabla dificulta recorrer el inventario. La búsqueda ayuda a localizar nombres concretos, pero no organiza el resto de la información.

## Propuesta y objetivo
Incorporar **paginación** para dividir el inventario en bloques de 10 medicamentos, de forma que una persona pueda navegar entre páginas sin perder el acceso al buscador por nombre.

## Funcionamiento técnico

- Se consulta el catálogo existente mediante `IProductoService.findAll()`.
- Cuando se escribe un filtro, el controlador obtiene la lista coincidente.
- `PaginacionUtil.totalPaginas(cantidad, 10)` calcula cuántas páginas son necesarias.
- `PaginacionUtil.obtenerPagina(lista, indice, 10)` obtiene solo los elementos que se muestran en la página actual.
- Los botones permiten ir a la página anterior o siguiente y se deshabilitan cuando corresponde.
- Al realizar una nueva búsqueda, se vuelve a la página 1.

La paginación es **local, en memoria**, no una paginación SQL `LIMIT/OFFSET`. Es adecuada para el catálogo de demostración y conserva la arquitectura existente. Para inventarios con miles de registros sería preferible consultar una página directamente desde H2.

## Ejemplo para explicar al profesor
Si el inventario tiene 23 medicamentos y cada página muestra 10:
- Página 1: medicamentos 1–10.
- Página 2: medicamentos 11–20.
- Página 3: medicamentos 21–23.

El cambio no altera registros, stock, precios ni ventas: solo organiza lo que se presenta en JavaFX.

## Aplicación de POO y capas
- **Vista (JavaFX FXML):** botones de navegación y etiqueta de página.
- **Controlador (`ProductoController`):** recibe eventos y actualiza la tabla.
- **Utilidad (`PaginacionUtil`):** encapsula el cálculo de páginas de forma reutilizable y verificable.
- **Servicio / repositorio:** el inventario continúa obteniéndose por sus capas habituales.

## Evidencias para la exposición
1. Mostrar la tabla con un inventario de más de diez productos.
2. Pulsar «Siguiente» y «Anterior».
3. Buscar un medicamento y verificar que cambie el total de resultados y de páginas.
4. Abrir `PaginacionUtil.java` y explicar los métodos `totalPaginas` y `obtenerPagina`.

**Nota:** el docente debe confirmar que esta función es adicional a las actividades realizadas durante el curso. La guía de evaluación menciona expresamente «paginación» como ejemplo de investigación adicional.
