# SysBotica — Etapa 1 de adecuación para la evaluación de POO

## Qué se modificó

Esta etapa parte de `SysVentas (2).zip` y **no cambia los datos guardados en la base H2**. Incluye el fichero original `data/sysbotica.mv.db` sin modificaciones.

1. **Perfiles:** `Reporte` accede al menú «Reporte diario»; `Root` y `Administrador` siguen teniendo inventario, ventas y reporte. Archivo: `service/impl/MenuMenuItemDaoImp.java`.
2. **Inicio de sesión:** avisa si faltan usuario o clave, borra el campo de contraseña cuando fallan las credenciales y comunica errores de conexión. Archivos: `controller/LoginController.java` y `repository/UsuarioRepository.java`.
3. **Estado de usuario:** solo se aceptan cuentas con estado `ACTIVO`, validado en la consulta de acceso.
4. **Validación de medicamentos:** es obligatorio seleccionar la marca; si falla el guardado, la pantalla informa del problema sin borrar lo escrito. Archivo: `controller/ProductoController.java`.
5. **Paginación local:** la tabla de medicamentos muestra 10 productos por página, con botones «Anterior» y «Siguiente». La búsqueda por nombre también se pagina. Archivos: `controller/ProductoController.java`, `utils/PaginacionUtil.java` y `view/main_producto.fxml`.
6. **Cuenta inicial:** el esquema crea el usuario demostrativo solo si aún no existe. De este modo, al iniciar el sistema **no sobrescribe una contraseña que ya fue cambiada**. Archivo: `schema_sv.sql`. La contraseña de demostración permanece en el script para una instalación nueva, por lo que se debe cambiar antes de un uso real.
7. **Pruebas automatizadas:** se añadieron `PaginacionUtilTest.java` y `MenuMenuItemDaoImpTest.java` (JUnit 5).

## Antes de abrir

- Guarda una copia de seguridad de `data/sysbotica.mv.db`.
- Cierra cualquier conexión abierta a esa base en DBeaver antes de ejecutar la aplicación para evitar bloqueos del archivo.
- Abre la carpeta `SysVentas` en IntelliJ IDEA y deja que Maven importe `pom.xml`.
- Utiliza **JDK 21**, como pide la configuración `pom.xml`.
- Ejecuta la clase principal `pe.edu.upeu.sysventas.SysVentas` o usa `mvn clean javafx:run` si tienes Maven disponible.
- Ejecuta el programa desde la carpeta del proyecto para que la ruta relativa `./data/sysbotica` apunte a la misma base.

## Pruebas manuales que debes realizar

| # | Prueba | Resultado esperado |
|---|---|---|
| 1 | Abrir la app e iniciar sesión con la cuenta habitual | Entra con normalidad y conserva sus datos |
| 2 | Pulsar «Ingresar» con usuario vacío | Mensaje: escribe tu nombre de usuario |
| 3 | Pulsar «Ingresar» con contraseña vacía | Mensaje: escribe tu contraseña |
| 4 | Ingresar una clave incorrecta | Error de acceso y campo de clave vacío |
| 5 | Iniciar sesión con usuario activo con perfil `Reporte` | Solo menú de salida y «Reporte diario» |
| 6 | Iniciar sesión con perfil `Root` o `Administrador` | Menús de productos, ventas y reporte |
| 7 | Abrir el inventario con más de 10 medicamentos | Muestra los primeros 10; «Siguiente» habilitado |
| 8 | Buscar por nombre de medicamento | Filtra la lista y pagina solo los resultados |
| 9 | Presionar «Mostrar todos» | Restaura el inventario completo desde la primera página |
| 10 | Registrar medicamento sin seleccionar marca | Presenta un mensaje explicando que falta la marca |
| 11 | Registrar medicamento válido | Se guarda en H2 y aparece en el inventario |
| 12 | Realizar una venta de prueba de un medicamento | Registra la venta, ajusta el stock y se refleja en el reporte diario |

**Importante:** para probar el perfil `Reporte` hace falta contar con una cuenta que tenga ese perfil; esta etapa no crea usuarios nuevos ni cambia las cuentas existentes.

## Verificación realizada en este entorno

- Compilación y prueba directa con `javac` de la clase pura Java `PaginacionUtil` (23 registros, última página y lista vacía): **OK**.
- Compilación y prueba directa de `MenuMenuItemDaoImp` con un DTO auxiliar equivalente para comprobar los tres perfiles: **OK**.
- Análisis sintáctico XML de `main_producto.fxml`: **OK**.
- **Pendiente de comprobar en IntelliJ:** la compilación Maven de toda la app, la ejecución de JavaFX, la conexión real a H2 y las pruebas de integración. Maven no está instalado en el entorno en el que se preparó esta etapa.

## Elementos de la evaluación todavía pendientes

- Diagrama físico editable en **SQL Power Architect**, acorde a las tablas reales de H2.
- Manual de usuario final, didáctico, con capturas reales y acceso por perfiles.
- Empaquetado y prueba de funcionamiento `.jar` o `.exe`.
- Confirmación del repositorio GitHub y acceso solicitado por el profesor.
- Guion de exposición y preguntas sobre arquitectura, POO y la nueva investigación.
- Confirmar con el docente que la paginación, no desarrollada en clase, cumple como funcionalidad investigada.

## Seguridad y conservación de datos

No se cambió el formato actual de contraseñas en la base de datos ni se migraron usuarios. **Las contraseñas todavía están almacenadas sin hash**; su mejora debe realizarse como un trabajo separado con una migración compatible. No uses esta aplicación para almacenar datos sensibles reales hasta completar esa protección.
